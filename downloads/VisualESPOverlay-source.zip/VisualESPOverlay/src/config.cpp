#include "esp/config.hpp"
#include <nlohmann/json.hpp>
#include <fstream>
#include <cmath>
#include <stdexcept>
namespace esp {
using nlohmann::json;
static void Validate(const VisualConfig& c) {
    ValidateRuntimeOptions(c.runtime);
    if(c.maxDrawEntities<1||c.maxDrawEntities>static_cast<int>(MaxFrameEntities)) throw std::runtime_error("draw budget must be 1..10000");
    auto range=[](float value,float low,float high,const char* message) {
        if(!std::isfinite(value)||value<low||value>high) throw std::runtime_error(message);
    };
    if(!std::isfinite(c.maxDistance)||c.maxDistance<1||c.maxDistance>1000) throw std::runtime_error("max_distance must be 1..1000");
    for(const auto& color:{c.survivorColor,c.killerColor}) for(float v:color)
        if(!std::isfinite(v)||v<0||v>1) throw std::runtime_error("color channels must be 0..1");
    range(c.camera.verticalFovDegrees,CameraSettings::MinFovDegrees,CameraSettings::MaxFovDegrees,"camera FOV must be 60..120 degrees");
    range(c.killerConeDegrees,30,120,"killer cone angle must be 30..120 degrees");
    range(c.killerArrowLength,1,20,"killer arrow length must be 1..20 meters");
    range(c.killerArrowOpacity,0,1,"killer arrow opacity must be 0..1");
    range(c.killerConeOpacity,0,1,"killer cone opacity must be 0..1");
    for(float v:c.killerArrowColor) range(v,0,1,"killer arrow color channels must be 0..1");
}
bool LoadConfig(const std::filesystem::path& path,VisualConfig& c,std::string& status) {
    try {
        if(!std::filesystem::exists(path)) {status="No config.json: defaults active";return false;}
        std::ifstream in(path); if(!in) throw std::runtime_error("cannot open config.json");
        const auto j=json::parse(in);
        if(j.at("schema_version")!=1) throw std::runtime_error("unsupported config schema");
        VisualConfig next;
        const auto& v=j.at("visuals");
        next.enabled=v.at("enabled"); next.survivors=v.at("survivors"); next.killer=v.at("killer");
        next.generators=v.at("generators"); next.hooks=v.at("hooks"); next.exitGates=v.at("exit_gates");
        next.names=v.at("names"); next.distances=v.at("distances"); next.maxDistance=v.at("max_distance");
        next.survivorColor=v.at("survivor_color").get<std::array<float,4>>();
        next.killerColor=v.at("killer_color").get<std::array<float,4>>();
        next.maxDrawEntities=v.value("max_draw_entities",next.maxDrawEntities);
        if(j.contains("runtime")) {
            const auto& r=j.at("runtime");
            const auto mode=r.value("source",std::string("demo"));
            if(mode=="demo") next.runtime.kind=SourceKind::Demo;
            else if(mode=="json") next.runtime.kind=SourceKind::JsonFile;
            else if(mode=="live_memory") next.runtime.kind=SourceKind::LiveMemory;
            else if(mode=="replay") next.runtime.kind=SourceKind::Replay;
            else throw std::runtime_error("runtime source must be demo, json, replay or live_memory");
            next.runtime.jsonPath=r.value("json_path",next.runtime.jsonPath);
            next.runtime.memoryLayoutPath=r.value("memory_layout_path",next.runtime.memoryLayoutPath);
            next.runtime.replayPath=r.value("replay_path",next.runtime.replayPath);
            next.runtime.recordingPath=r.value("recording_path",next.runtime.recordingPath);
            next.runtime.fallbackDemo=r.value("fallback_demo",next.runtime.fallbackDemo);
            next.runtime.replayLoop=r.value("replay_loop",next.runtime.replayLoop);
            next.runtime.record=r.value("record",next.runtime.record);
            next.runtime.pollMs=r.value("poll_ms",next.runtime.pollMs);
            next.runtime.staleMs=r.value("stale_ms",next.runtime.staleMs);
        }
        // Existing schema-1 configs remain valid; absent new fields use defaults.
        if(j.contains("camera")) next.camera.verticalFovDegrees=j.at("camera").value("vertical_fov_degrees",next.camera.verticalFovDegrees);
        next.killerDirection=v.value("killer_direction",next.killerDirection);
        next.killerCone=v.value("killer_cone",next.killerCone);
        next.killerConeDegrees=v.value("killer_cone_degrees",next.killerConeDegrees);
        next.killerArrowLength=v.value("killer_arrow_length",next.killerArrowLength);
        next.killerArrowColor=v.value("killer_arrow_color",next.killerArrowColor);
        next.killerArrowOpacity=v.value("killer_arrow_opacity",next.killerArrowOpacity);
        next.killerConeOpacity=v.value("killer_cone_opacity",next.killerConeOpacity);
        Validate(next); c=next; status="Loaded config.json";return true;
    } catch(const std::exception& e) { status=std::string("Load failed: ")+e.what();return false; }
}
bool SaveConfig(const std::filesystem::path& path,const VisualConfig& c,std::string& status) {
    try {
        Validate(c);
        const auto& o=c.runtime;
        const json runtime={{"source",o.kind==SourceKind::Demo?"demo":o.kind==SourceKind::JsonFile?"json":o.kind==SourceKind::LiveMemory?"live_memory":"replay"},
            {"memory_layout_path",o.memoryLayoutPath},{"json_path",o.jsonPath},{"replay_path",o.replayPath},{"recording_path",o.recordingPath},
            {"fallback_demo",o.fallbackDemo},{"replay_loop",o.replayLoop},{"record",o.record},{"poll_ms",o.pollMs},{"stale_ms",o.staleMs}};
        const json j={{"runtime",runtime},{"schema_version",1},{"camera",{{"vertical_fov_degrees",c.camera.verticalFovDegrees}}},{"visuals",{
            {"enabled",c.enabled},{"survivors",c.survivors},{"killer",c.killer},
            {"generators",c.generators},{"hooks",c.hooks},{"exit_gates",c.exitGates},
            {"names",c.names},{"distances",c.distances},{"max_distance",c.maxDistance},{"max_draw_entities",c.maxDrawEntities},
            {"survivor_color",c.survivorColor},{"killer_color",c.killerColor},
            {"killer_direction",c.killerDirection},{"killer_cone",c.killerCone},
            {"killer_cone_degrees",c.killerConeDegrees},{"killer_arrow_length",c.killerArrowLength},
            {"killer_arrow_color",c.killerArrowColor},{"killer_arrow_opacity",c.killerArrowOpacity},
            {"killer_cone_opacity",c.killerConeOpacity}}}};
        auto temporary=path; temporary+=".tmp";
        {std::ofstream out(temporary,std::ios::trunc);out.exceptions(std::ios::failbit|std::ios::badbit);out<<j.dump(2)<<'\n';out.close();}
        // Copy-over preserves the old file until a complete temporary file exists.
        std::filesystem::copy_file(temporary,path,std::filesystem::copy_options::overwrite_existing);
        std::filesystem::remove(temporary);
        status="Saved config.json";return true;
    } catch(const std::exception& e) {status=std::string("Save failed: ")+e.what();return false;}
}
bool ValidateOffsets(const std::filesystem::path& path,std::string& status) {
    try {
        std::ifstream in(path); if(!in) throw std::runtime_error("offsets.json not found");
        const auto j=json::parse(in);
        if(j.at("schema_version")!=1||j.at("target_version")!="10.2.2") throw std::runtime_error("unsupported offsets schema/version");
        if(j.at("provider")!="demo") throw std::runtime_error("DBD layout is unverified; generic live_memory uses a separate verified layout");
        status="offsets.json: unused by JSON/replay/live memory; game addresses are not configured";return true;
    } catch(const std::exception& e) {status=std::string("Offsets: ")+e.what();return false;}
}
}
